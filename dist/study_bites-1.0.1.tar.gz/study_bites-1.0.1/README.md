# study_bites
Application that provides curated healthy and accessible options based on students' location powered by Qloo Taste AI™ API and Hugging Face Image LLM.
